import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Campaign, AutomationRule } from '../types';
import { Megaphone, Zap, Plus, Play, Pause, TrendingUp, CheckCircle, Clock } from 'lucide-react';

export const CampaignsAutomationsView: React.FC = () => {
  const { campaigns, automations } = useApp();
  const [activeTab, setActiveTab] = useState<'campanhas' | 'automacoes'>('campanhas');

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Megaphone className="w-6 h-6 text-indigo-400" />
            Campanhas & Automações Inteligentes
          </h1>
          <p className="text-xs text-slate-400">
            Crie disparos em massa agendados ou configure gatilhos automáticos de queda de preço e novos cupons.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-900 border border-slate-800">
          <button
            onClick={() => setActiveTab('campanhas')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'campanhas' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Campanhas ({campaigns.length})
          </button>
          <button
            onClick={() => setActiveTab('automacoes')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'automacoes' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Regras de Gatilho ({automations.length})
          </button>
        </div>
      </div>

      {activeTab === 'campanhas' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {campaigns.map(camp => (
            <div key={camp.id} className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/80 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-500/30">
                  {camp.type}
                </span>
                <span className="text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 capitalize">
                  {camp.status}
                </span>
              </div>

              <h3 className="text-sm font-bold text-white">{camp.name}</h3>

              <div className="grid grid-cols-2 gap-2 text-xs pt-2 border-t border-slate-800">
                <div>
                  <span className="text-slate-400 block text-[10px]">Disparos:</span>
                  <span className="font-bold text-white">{camp.totalSent}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Cliques:</span>
                  <span className="font-bold text-indigo-400">{camp.clicks}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Conversões:</span>
                  <span className="font-bold text-emerald-400">{camp.conversions}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px]">Receita:</span>
                  <span className="font-bold text-emerald-400">R$ {camp.revenue.toFixed(2)}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {automations.map(auto => (
            <div key={auto.id} className="p-5 rounded-2xl bg-slate-900/90 border border-slate-800/80 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  <h3 className="text-sm font-bold text-white">{auto.name}</h3>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
                    {auto.status}
                  </span>
                </div>
                <p className="text-xs text-slate-400">
                  <strong className="text-indigo-300">Gatilho:</strong> {auto.triggerCondition} → <strong className="text-emerald-300">Ação:</strong> {auto.action}
                </p>
              </div>

              <div className="text-right text-xs text-slate-400">
                <span>Disparado <strong className="text-white">{auto.triggerCount} vezes</strong></span>
                <span className="block text-[10px] text-slate-500">Último disparo: {auto.lastTriggered}</span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
