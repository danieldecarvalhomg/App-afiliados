import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  DollarSign,
  MousePointer,
  CheckCircle,
  TrendingUp,
  ShoppingBag,
  Megaphone,
  Zap,
  Send,
  Flame,
  AlertTriangle,
  Clock,
  ArrowUpRight,
  Filter,
  Sparkles,
  ChevronRight,
  BarChart2,
  Calendar
} from 'lucide-react';

export const DashboardView: React.FC = () => {
  const { products, queueItems, queues, campaigns, automations, logs, setActiveTab, addQueueItem } = useApp();
  const [timeframe, setTimeframe] = useState<'24h' | '7d' | '30d' | '90d'>('7d');

  const hotProducts = products.filter(p => p.status === 'ativo').sort((a, b) => b.hotScore - a.hotScore).slice(0, 4);
  const pendingCount = queueItems.filter(i => i.status === 'pendente').length;
  const brokenLinks = products.filter(p => p.status === 'link_quebrado');

  // Chart data simulation depending on timeframe
  const chartData = {
    '24h': [
      { label: '00h', sales: 1200, clicks: 450, conversions: 12 },
      { label: '04h', sales: 800, clicks: 210, conversions: 6 },
      { label: '08h', sales: 4200, clicks: 1200, conversions: 42 },
      { label: '12h', sales: 8900, clicks: 2800, conversions: 89 },
      { label: '16h', sales: 6400, clicks: 1900, conversions: 54 },
      { label: '20h', sales: 9800, clicks: 3100, conversions: 98 },
    ],
    '7d': [
      { label: 'Seg', sales: 6200, clicks: 1800, conversions: 48 },
      { label: 'Ter', sales: 8100, clicks: 2400, conversions: 64 },
      { label: 'Qua', sales: 7400, clicks: 2100, conversions: 59 },
      { label: 'Qui', sales: 9800, clicks: 3100, conversions: 82 },
      { label: 'Sex', sales: 12400, clicks: 4200, conversions: 112 },
      { label: 'Sáb', sales: 14200, clicks: 4800, conversions: 128 },
      { label: 'Dom', sales: 11000, clicks: 3600, conversions: 95 },
    ],
    '30d': [
      { label: 'Sem 1', sales: 32000, clicks: 9800, conversions: 240 },
      { label: 'Sem 2', sales: 41000, clicks: 12400, conversions: 310 },
      { label: 'Sem 3', sales: 38000, clicks: 11200, conversions: 285 },
      { label: 'Sem 4', sales: 52000, clicks: 16800, conversions: 410 },
    ],
    '90d': [
      { label: 'Mai', sales: 112000, clicks: 34000, conversions: 890 },
      { label: 'Jun', sales: 145000, clicks: 42000, conversions: 1120 },
      { label: 'Jul', sales: 168000, clicks: 51000, conversions: 1340 },
    ]
  }[timeframe];

  // Peak posting hours heatmap data
  const peakHours = [
    { hour: '08:00', engagement: 'Alta', color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' },
    { hour: '11:30', engagement: 'Máxima 🔥', color: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40' },
    { hour: '14:00', engagement: 'Média', color: 'bg-amber-500/20 text-amber-400 border-amber-500/30' },
    { hour: '18:30', engagement: 'Máxima 🔥', color: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/40' },
    { hour: '21:00', engagement: 'Alta', color: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' },
  ];

  return (
    <div className="space-y-8 pb-12">
      {/* Greeting & Quick Header Actions */}
      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white tracking-tight">Bem-vindo, Daniel</h1>
          <p className="text-slate-400 text-sm mt-1">Seu ecossistema de afiliados está operando em alta performance hoje.</p>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setActiveTab('filas')}
            className="px-4 py-2 bg-white/5 border border-white/10 rounded-lg text-xs font-medium text-slate-200 hover:bg-white/10 hover:text-white transition-all"
          >
            Configurar Filas
          </button>
          <button
            onClick={() => setActiveTab('ia')}
            className="px-4 py-2 bg-indigo-600 rounded-lg text-xs font-bold text-white shadow-lg shadow-indigo-500/20 hover:bg-indigo-500 transition-all flex items-center gap-2"
          >
            <Sparkles className="w-3.5 h-3.5" />
            + Nova Campanha IA
          </button>
        </div>
      </div>

      {/* Key Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {/* Receita Estimada */}
        <div className="p-5 bg-white/[0.03] border border-white/5 rounded-2xl backdrop-blur-md hover:border-white/10 transition-all">
          <div className="flex justify-between items-start">
            <div className="text-xs font-medium text-slate-500 uppercase tracking-wider">Receita Estimada</div>
            <span className="text-emerald-400 text-[10px] bg-emerald-400/10 px-1.5 py-0.5 rounded font-semibold">+12.5%</span>
          </div>
          <div className="text-2xl font-bold text-white mt-2">R$ 57.300,00</div>
          <div className="text-[10px] text-slate-500 mt-2">Vs. R$ 48.120,00 (mês anterior)</div>
        </div>

        {/* Total Cliques */}
        <div className="p-5 bg-white/[0.03] border border-white/5 rounded-2xl backdrop-blur-md hover:border-white/10 transition-all">
          <div className="flex justify-between items-start">
            <div className="text-xs font-medium text-slate-500 uppercase tracking-wider">Total Cliques</div>
            <span className="text-emerald-400 text-[10px] bg-emerald-400/10 px-1.5 py-0.5 rounded font-semibold">+8.2%</span>
          </div>
          <div className="text-2xl font-bold text-white mt-2">156.402</div>
          <div
            onClick={() => setActiveTab('analytics')}
            className="text-[10px] text-indigo-400 hover:text-indigo-300 underline cursor-pointer mt-2 inline-block"
          >
            Ver mapa de calor
          </div>
        </div>

        {/* Conversão (CTR) */}
        <div className="p-5 bg-white/[0.03] border border-white/5 rounded-2xl backdrop-blur-md hover:border-white/10 transition-all">
          <div className="flex justify-between items-start">
            <div className="text-xs font-medium text-slate-500 uppercase tracking-wider">Conversão (CTR)</div>
            <span className="text-emerald-400 text-[10px] bg-emerald-400/10 px-1.5 py-0.5 rounded font-semibold">+1.8%</span>
          </div>
          <div className="text-2xl font-bold text-white mt-2">3.84%</div>
          <div className="w-full h-1 bg-white/5 rounded-full mt-3 overflow-hidden">
            <div className="w-[38%] h-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]"></div>
          </div>
        </div>

        {/* Automações Ativas */}
        <div className="p-5 bg-white/[0.03] border border-white/5 rounded-2xl backdrop-blur-md hover:border-white/10 transition-all">
          <div className="flex justify-between items-start">
            <div className="text-xs font-medium text-slate-500 uppercase tracking-wider">Automações Ativas</div>
            <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse mt-1"></span>
          </div>
          <div className="text-2xl font-bold text-white mt-2">12 / 15</div>
          <div className="text-[10px] text-slate-500 mt-2">{pendingCount} agendadas para disparo</div>
        </div>
      </div>

      {/* Main Row: Queue & Integrations Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Queue Monitor & Growth Bar Section */}
        <div className="lg:col-span-8 bg-white/[0.02] border border-white/5 rounded-3xl p-6 relative overflow-hidden flex flex-col justify-between">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h3 className="font-bold text-lg text-white">Monitoramento de Filas Inteligentes</h3>
              <p className="text-xs text-slate-400">Desempenho de automação e filas de disparo em tempo real.</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3 py-1 bg-indigo-500 text-[10px] font-bold text-white rounded-full">TEMPO REAL</span>
              <span className="px-3 py-1 bg-white/5 text-[10px] text-slate-400 rounded-full">HISTÓRICO</span>
            </div>
          </div>

          {/* Queue Items Table / List */}
          <div className="space-y-3 z-10">
            <div className="grid grid-cols-5 text-[10px] uppercase font-bold text-slate-500 px-4 border-b border-white/5 pb-2">
              <div className="col-span-2">NOME DA FILA</div>
              <div>STATUS</div>
              <div>PENDENTE</div>
              <div className="text-right">AÇÃO</div>
            </div>

            {queues.slice(0, 3).map((q, idx) => (
              <div
                key={q.id}
                className="grid grid-cols-5 items-center px-4 py-3 bg-white/[0.03] rounded-xl hover:bg-white/[0.05] transition-colors border border-transparent hover:border-white/10"
              >
                <div className="col-span-2 flex items-center gap-3">
                  <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-bold text-xs ${
                    idx === 0 ? 'bg-blue-500/20 text-blue-400' : idx === 1 ? 'bg-emerald-500/20 text-emerald-400' : 'bg-orange-500/20 text-orange-400'
                  }`}>
                    {(q.platform || q.channelName || 'Fila').charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-white">{q.name}</div>
                    <div className="text-[9px] text-slate-500">Intervalo: {q.intervalMinutes}m • {q.channelName}</div>
                  </div>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className={`w-1.5 h-1.5 rounded-full ${q.status === 'ativa' ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
                  <span className="text-[10px] text-emerald-400 uppercase font-bold">{q.status}</span>
                </div>

                <div className="text-xs font-mono text-slate-200">
                  {queueItems.filter(i => i.status === 'pendente').length} itens
                </div>

                <div
                  onClick={() => setActiveTab('filas')}
                  className="text-right text-indigo-400 hover:text-indigo-300 text-[10px] font-bold cursor-pointer"
                >
                  GERENCIAR
                </div>
              </div>
            ))}
          </div>

          {/* Visual Graph Curve Hint */}
          <div className="mt-8 pt-6 border-t border-white/5">
            <div className="flex items-center justify-between text-xs mb-3">
              <span className="text-slate-400 font-semibold">Volume de Disparos por Horário (Pico)</span>
              <span className="text-indigo-400 font-mono text-[11px]">890 disparos / hr</span>
            </div>
            <div className="h-20 w-full relative opacity-80">
              <svg viewBox="0 0 400 100" className="w-full h-full preserve-3d">
                <path d="M0,70 Q50,20 100,50 T200,30 T300,60 T400,20 L400,100 L0,100 Z" fill="url(#grad)" />
                <path d="M0,70 Q50,20 100,50 T200,30 T300,60 T400,20" fill="none" stroke="#6366f1" strokeWidth="2" />
                <defs>
                  <linearGradient id="grad" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" style={{ stopColor: 'rgb(99,102,241)', stopOpacity: 0.4 }} />
                    <stop offset="100%" style={{ stopColor: 'rgb(99,102,241)', stopOpacity: 0 }} />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
        </div>

        {/* Quick Integrations & AI Strategy Spotlight */}
        <div className="lg:col-span-4 bg-white/[0.02] border border-white/5 rounded-3xl p-6 flex flex-col justify-between">
          <div>
            <h3 className="font-bold text-lg text-white mb-5">Marketplaces & Integrações</h3>
            <div className="space-y-3">
              <div className="p-4 bg-black/40 border border-white/5 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-amber-600/20 border border-amber-500/30 rounded-xl flex items-center justify-center font-bold text-xs text-amber-400">AMZ</div>
                  <div>
                    <div className="text-xs font-bold text-white">Amazon Brasil</div>
                    <div className="text-[9px] text-emerald-400 font-medium">● Conectado</div>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('integracoes')}
                  className="text-[10px] font-bold bg-white/10 hover:bg-white/20 text-slate-200 px-3 py-1 rounded-full transition-colors"
                >
                  Logs
                </button>
              </div>

              <div className="p-4 bg-black/40 border border-white/5 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-blue-600/20 border border-blue-500/30 rounded-xl flex items-center justify-center font-bold text-xs text-blue-400">ML</div>
                  <div>
                    <div className="text-xs font-bold text-white">Mercado Livre</div>
                    <div className="text-[9px] text-emerald-400 font-medium">● Conectado</div>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('integracoes')}
                  className="text-[10px] font-bold bg-white/10 hover:bg-white/20 text-slate-200 px-3 py-1 rounded-full transition-colors"
                >
                  Logs
                </button>
              </div>

              <div className="p-4 bg-black/40 border border-white/5 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-500/20 border border-orange-500/30 rounded-xl flex items-center justify-center font-bold text-xs text-orange-400">SHP</div>
                  <div>
                    <div className="text-xs font-bold text-white">Shopee Oficial</div>
                    <div className="text-[9px] text-emerald-400 font-medium">● Conectado</div>
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('integracoes')}
                  className="text-[10px] font-bold bg-white/10 hover:bg-white/20 text-slate-200 px-3 py-1 rounded-full transition-colors"
                >
                  Logs
                </button>
              </div>
            </div>
          </div>

          {/* Destaque IA do Dia */}
          <div className="mt-6 pt-5 border-t border-white/5">
            <div className="text-xs font-bold text-slate-400 mb-3 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>Destaque IA do Dia</span>
            </div>
            <div className="p-4 bg-indigo-900/10 border border-indigo-500/30 rounded-2xl relative">
              <div className="text-[10px] text-indigo-400 font-bold uppercase mb-1 tracking-wider italic">Nova Oportunidade Gemini</div>
              <div className="text-xs text-slate-200 font-medium leading-relaxed italic">
                "Fones Bluetooth em alta no Telegram. Sugestão: Iniciar campanha com cupom de 20% às 18:30."
              </div>
              <button
                onClick={() => setActiveTab('ia')}
                className="mt-3 w-full py-2 bg-indigo-500/20 text-indigo-300 hover:bg-indigo-500/30 text-[10px] font-bold rounded-lg transition-all uppercase tracking-widest border border-indigo-500/30"
              >
                Aplicar Estratégia
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Split Section: Hot Products & Peak Posting Heatmap */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hot Products Slider / List */}
        <div className="lg:col-span-2 p-6 rounded-3xl bg-white/[0.02] border border-white/5 shadow-xl space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-400" />
              <h2 className="text-base font-bold text-white">Produtos em Alta (Alta Conversão)</h2>
            </div>
            <button
              onClick={() => setActiveTab('produtos')}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 transition-colors flex items-center gap-1"
            >
              Ver catálogo completo <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {hotProducts.map(prod => (
              <div
                key={prod.id}
                className="p-4 rounded-2xl bg-black/40 border border-white/5 hover:border-white/10 transition-all flex gap-3 group"
              >
                <img src={prod.image} alt={prod.title} className="w-16 h-16 rounded-xl object-cover shrink-0" />
                <div className="flex-1 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-white/10 text-indigo-300">
                      {prod.marketplace}
                    </span>
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                      <Flame className="w-3 h-3 text-amber-400" />
                      {prod.hotScore} HotScore
                    </span>
                  </div>

                  <h3 className="text-xs font-semibold text-white line-clamp-1 group-hover:text-indigo-300 transition-colors">
                    {prod.title}
                  </h3>

                  <div className="flex items-center justify-between pt-1">
                    <div>
                      <span className="text-xs font-bold text-emerald-400">R$ {prod.price.toFixed(2)}</span>
                      {prod.originalPrice > prod.price && (
                        <span className="text-[10px] text-slate-500 line-through ml-1.5">
                          R$ {prod.originalPrice.toFixed(2)}
                        </span>
                      )}
                    </div>
                    <button
                      onClick={() => {
                        addQueueItem({
                          productId: prod.id,
                          productTitle: prod.title,
                          productImage: prod.image,
                          price: prod.price,
                          originalPrice: prod.originalPrice,
                          marketplace: prod.marketplace,
                          affiliateUrl: prod.affiliateUrl,
                          copyText: `🔥 *${prod.title}*\nDe ~R$ ${prod.originalPrice}~ por apenas *R$ ${prod.price}*!\n👉 Comprar: ${prod.affiliateUrl}`
                        });
                      }}
                      className="p-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white transition-colors"
                      title="Enviar direto para fila"
                    >
                      <Send className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Melhores Horários / Peak Heatmap */}
        <div className="p-6 rounded-3xl bg-white/[0.02] border border-white/5 shadow-xl space-y-5">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-400" />
            <h2 className="text-base font-bold text-white">Melhores Horários</h2>
          </div>
          <p className="text-xs text-slate-400">Picos de engajamento baseados em mais de 100 mil cliques de afiliados.</p>

          <div className="space-y-3 pt-2">
            {peakHours.map((ph, idx) => (
              <div key={idx} className="p-3 rounded-xl bg-black/40 border border-white/5 flex items-center justify-between">
                <span className="text-xs font-bold text-slate-200">{ph.hour}</span>
                <span className={`px-2.5 py-1 text-[10px] font-bold rounded-lg border ${ph.color}`}>
                  {ph.engagement}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Alerts & Urgent Notifications Section */}
      {brokenLinks.length > 0 && (
        <div className="p-5 rounded-2xl bg-rose-950/30 border border-rose-500/30 shadow-lg flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-400 border border-rose-500/30 shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-xs font-bold text-rose-200">Atenção: {brokenLinks.length} produto(s) com link quebrado ou 404</h3>
              <p className="text-[11px] text-slate-400">Foram automaticamente pausados para evitar perda de cliques.</p>
            </div>
          </div>

          <button
            onClick={() => setActiveTab('produtos')}
            className="px-4 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-semibold shadow-md transition-colors whitespace-nowrap"
          >
            Corrigir Links Agora
          </button>
        </div>
      )}

      {/* Timeline de Atividades */}
      <div className="p-6 rounded-3xl bg-white/[0.02] border border-white/5 shadow-xl space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <Zap className="w-5 h-5 text-indigo-400" />
          Timeline de Atividades Recentes
        </h2>

        <div className="divide-y divide-white/5">
          {logs.slice(0, 5).map(log => (
            <div key={log.id} className="py-3 flex items-start gap-3 text-xs">
              <span className="text-[10px] font-mono text-slate-500 shrink-0 mt-0.5">{log.timestamp.split(' ')[1] || 'Agora'}</span>
              <div className="flex-1 space-y-0.5">
                <p className="font-semibold text-slate-200">{log.message}</p>
                {log.details && <p className="text-[11px] text-slate-400">{log.details}</p>}
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-white/5 text-slate-400">
                {log.module}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
