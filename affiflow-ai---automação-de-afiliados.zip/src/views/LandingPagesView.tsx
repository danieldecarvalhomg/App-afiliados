import React from 'react';
import { useApp } from '../context/AppContext';
import { Globe, Eye, MousePointer, ExternalLink, Plus, Sparkles } from 'lucide-react';

export const LandingPagesView: React.FC = () => {
  const { landingPages } = useApp();

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Globe className="w-6 h-6 text-indigo-400" />
            Landing Pages & Bio Links de Ofertas
          </h1>
          <p className="text-xs text-slate-400">
            Crie páginas de alta velocidade para bio do Instagram e WhatsApp com contagem regressiva e botões diretos de afiliados.
          </p>
        </div>

        <button className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold shadow-md flex items-center gap-2">
          <Plus className="w-4 h-4" />
          Nova Landing Page
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {landingPages.map(lp => (
          <div key={lp.id} className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800/80 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-indigo-400 font-mono">/page/{lp.slug}</span>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 uppercase">
                {lp.status}
              </span>
            </div>

            <h3 className="text-base font-bold text-white">{lp.title}</h3>

            <div className="grid grid-cols-3 gap-2 p-3 rounded-2xl bg-slate-950 border border-slate-800 text-xs">
              <div>
                <span className="text-slate-500 block text-[10px]">Visualizações:</span>
                <span className="font-bold text-white">{lp.views.toLocaleString('pt-BR')}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Cliques:</span>
                <span className="font-bold text-indigo-400">{lp.clicks.toLocaleString('pt-BR')}</span>
              </div>
              <div>
                <span className="text-slate-500 block text-[10px]">Conversão:</span>
                <span className="font-bold text-emerald-400">{lp.conversionRate}%</span>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5">
                <ExternalLink className="w-3.5 h-3.5" /> Ver Página
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
