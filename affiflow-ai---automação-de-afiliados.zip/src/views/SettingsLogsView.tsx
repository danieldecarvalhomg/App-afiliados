import React from 'react';
import { useApp } from '../context/AppContext';
import { Settings, FileText, ShieldAlert, CheckCircle2 } from 'lucide-react';

export const SettingsLogsView: React.FC = () => {
  const { logs } = useApp();

  return (
    <div className="space-y-6 pb-12">
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
          <Settings className="w-6 h-6 text-indigo-400" />
          Configurações Globais & Auditoria de Logs
        </h1>
        <p className="text-xs text-slate-400">
          Acompanhe requisições de API, eventos de webhooks e registros de auditoria do sistema em tempo real.
        </p>
      </div>

      <div className="overflow-x-auto rounded-3xl border border-slate-800 bg-slate-900/90 shadow-xl">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase font-semibold">
            <tr>
              <th className="p-4">Data / Horário</th>
              <th className="p-4">Nível</th>
              <th className="p-4">Módulo</th>
              <th className="p-4">Mensagem de Evento</th>
              <th className="p-4">Detalhes Técnicos</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono">
            {logs.map(log => (
              <tr key={log.id} className="hover:bg-slate-800/40 transition-colors">
                <td className="p-4 text-slate-400 whitespace-nowrap">{log.timestamp}</td>
                <td className="p-4 uppercase font-bold">
                  {log.level === 'success' && <span className="text-emerald-400">SUCCESS</span>}
                  {log.level === 'info' && <span className="text-indigo-400">INFO</span>}
                  {log.level === 'warning' && <span className="text-amber-400">WARN</span>}
                  {log.level === 'error' && <span className="text-rose-400">ERROR</span>}
                </td>
                <td className="p-4 font-bold text-slate-200">{log.module}</td>
                <td className="p-4 text-slate-300 font-sans">{log.message}</td>
                <td className="p-4 text-slate-400 text-[11px] max-w-xs truncate">{log.details || '-'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
