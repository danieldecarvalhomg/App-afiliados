import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Bookmark, Search, Layers, Copy, Trash2, FolderPlus, Star, Archive } from 'lucide-react';

export const LibraryView: React.FC = () => {
  const { products, toggleFavoriteProduct, deleteProduct, updateProduct, addLog } = useApp();

  const [activeTab, setActiveTab] = useState<'favoritos' | 'colecoes' | 'arquivados'>('favoritos');
  const [search, setSearch] = useState('');

  const favoriteProducts = products.filter(p => p.isFavorite);
  const archivedProducts = products.filter(p => p.isArchived);

  const collections = [
    { id: 'col-tech', name: 'Super Ofertas Tech & Gamer', count: products.filter(p => p.collectionId === 'col-tech').length },
    { id: 'col-casa', name: 'Achadinhos para Casa & Cozinha', count: products.filter(p => p.collectionId === 'col-casa').length },
    { id: 'col-black', name: 'Especial Black Friday 2026', count: 8 },
  ];

  return (
    <div className="space-y-6 pb-12">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
            <Bookmark className="w-6 h-6 text-indigo-400" />
            Biblioteca & Organização de Acervo
          </h1>
          <p className="text-xs text-slate-400">
            Coleções personalizadas, itens favoritos, históricos de ofertas e ações de duplicação em massa.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 rounded-xl bg-slate-900 border border-slate-800">
          <button
            onClick={() => setActiveTab('favoritos')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'favoritos' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Favoritos ({favoriteProducts.length})
          </button>
          <button
            onClick={() => setActiveTab('colecoes')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'colecoes' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Coleções ({collections.length})
          </button>
          <button
            onClick={() => setActiveTab('arquivados')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              activeTab === 'arquivados' ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-400 hover:text-white'
            }`}
          >
            Arquivados ({archivedProducts.length})
          </button>
        </div>
      </div>

      {activeTab === 'favoritos' && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {favoriteProducts.map(p => (
            <div key={p.id} className="p-5 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3">
              <img src={p.image} alt={p.title} className="w-full h-36 rounded-2xl object-cover" />
              <h3 className="text-xs font-bold text-white line-clamp-2">{p.title}</h3>
              <div className="flex items-center justify-between text-xs">
                <span className="font-bold text-emerald-400">R$ {p.price.toFixed(2)}</span>
                <button onClick={() => toggleFavoriteProduct(p.id)} className="text-rose-400 text-[11px] font-semibold">
                  Remover Favorito
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'colecoes' && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {collections.map(col => (
            <div key={col.id} className="p-6 rounded-3xl bg-slate-900/90 border border-slate-800 space-y-3">
              <div className="flex items-center gap-2">
                <Layers className="w-5 h-5 text-indigo-400" />
                <h3 className="text-sm font-bold text-white">{col.name}</h3>
              </div>
              <p className="text-xs text-slate-400">{col.count} ofertas vinculadas nesta coleção</p>
              <button className="w-full py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-slate-200">
                Abrir Coleção
              </button>
            </div>
          ))}
        </div>
      )}

      {activeTab === 'arquivados' && (
        <div className="text-xs text-slate-400 text-center py-12 bg-slate-900/40 rounded-3xl border border-slate-800">
          Nenhum item arquivado no momento.
        </div>
      )}
    </div>
  );
};
