import React from 'react';
import { useApp } from '../context/AppContext';
import { Users, Phone, Send, Tag, Flame } from 'lucide-react';

export const CrmView: React.FC = () => {
  const { leads } = useApp();

  return (
    <div className="space-y-6 pb-12">
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2.5">
          <Users className="w-6 h-6 text-violet-400" />
          CRM de Afiliados & Gestão de Contatos VIP
        </h1>
        <p className="text-xs text-slate-400">
          Segmentação de membros engajados dos seus canais de Telegram e WhatsApp com tags e histórico de cliques.
        </p>
      </div>

      <div className="overflow-x-auto rounded-3xl border border-slate-800 bg-slate-900/90 shadow-xl">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-950 text-slate-400 border-b border-slate-800 uppercase font-semibold">
            <tr>
              <th className="p-4">Membro / Contato</th>
              <th className="p-4">Plataforma</th>
              <th className="p-4">Tags de Interesse</th>
              <th className="p-4">Score de Engajamento</th>
              <th className="p-4">Total Cliques</th>
              <th className="p-4">Última Atividade</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60">
            {leads.map(lead => (
              <tr key={lead.id} className="hover:bg-slate-800/40 transition-colors">
                <td className="p-4 font-bold text-white">
                  {lead.name}
                  <span className="block text-[11px] font-mono text-slate-400 font-normal">{lead.handleOrPhone}</span>
                </td>
                <td className="p-4">
                  <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-indigo-500/20 text-indigo-300">
                    {lead.platform}
                  </span>
                </td>
                <td className="p-4">
                  <div className="flex flex-wrap gap-1">
                    {lead.tags.map((t, idx) => (
                      <span key={idx} className="px-2 py-0.5 rounded text-[10px] bg-slate-800 text-slate-300">
                        {t}
                      </span>
                    ))}
                  </div>
                </td>
                <td className="p-4 font-bold text-amber-400 flex items-center gap-1">
                  <Flame className="w-3.5 h-3.5" />
                  {lead.engagementScore} pts
                </td>
                <td className="p-4 font-bold text-emerald-400">{lead.totalClicks} cliques</td>
                <td className="p-4 text-slate-400">{lead.lastActive}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};
